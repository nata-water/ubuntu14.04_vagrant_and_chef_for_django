default["vagrant"]["proxy"] = "http://2615850:artemarinne305@prxb321.plain.sharedom.net:8080"
default["vagrant"]["home"] = "/home/vagrant"
default["vagrant"]["user"] = "vagrant"