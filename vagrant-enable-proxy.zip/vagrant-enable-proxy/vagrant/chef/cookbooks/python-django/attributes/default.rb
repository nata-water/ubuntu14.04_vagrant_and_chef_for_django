default["vagrant"]["proxy"] = "http://user:password@server:port"
default["vagrant"]["home"] = "/home/vagrant"
default["vagrant"]["user"] = "vagrant"